We're using ducks modular patter here to minimize amount of files developers
need to create do get started with redux.

So each "duck" exports `{ actions, actionTypes, reducer, selectors, saga }`.

See more at [official ducks proposal](https://github.com/erikras/ducks-modular-redux).
